#ifndef _string_parse_h_
#define _string_parse_h_

extern StringParse_t StringParse;

#endif