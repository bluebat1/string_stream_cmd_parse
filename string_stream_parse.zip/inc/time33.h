#ifndef _time33_h_
#define _time33_h_

#include <stdint.h>
uint32_t time33(const char *arKey, uint16_t nKeyLength);

#endif